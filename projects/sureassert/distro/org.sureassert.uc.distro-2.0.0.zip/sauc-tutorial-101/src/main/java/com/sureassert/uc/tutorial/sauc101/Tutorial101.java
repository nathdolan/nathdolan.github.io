/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.sauc101;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.sureassert.uc.annotation.Exemplar;
import org.sureassert.uc.annotation.Exemplars;
import org.sureassert.uc.annotation.IgnoreTestCoverage;
import org.sureassert.uc.annotation.UseCase;

/**
 * An example class containing a series of examples demonstrating Sureassert UC. 
 * 
 * If you are new to Sureassert UC, start here before looking at the PhoneShopService example.
 * 
 * This demonstrates Exemplars on static methods.  See the PhoneShopService for examples of
 * how to set the object-under-test via the Exemplar instance.
 */
public class Tutorial101 { 

	/**
	 * Adds x to y and returns the result.
	 * @param x Any number
	 * @param y Any number
	 * @return x+y
	 */   
	// Sureassert UC Tutorial
	// ==============================================================================
	// - The add method is annotated with an @Exemplar
	//
	// - We supply an array of "args", one for each parameter of the add method
	//
	// - Each supplied arg is a SIN Expression, which in its most basic form
	//   is a SIN Type value like an integer or String.
	//
	// - We also supply a single "expect" value of 3. 
	//
	// - Just like "args", "expects" are SIN Expressions which can be single
	//   values or more complicated expressions.
	//
	// - See the javadoc for @Exemplar for reference documentation on SIN 
	//   Expressions and Types (just hover the cursor over @Exemplar below.
	//
	// - Sureassert UC runs whenever you save changes to your java files, as long
	//   as Eclipse is set to build automatically (Run->Build Automatically).  
	//   It will also run whenever you explicitly request an Eclipse build.
	//
	// - Assuming you have activated Sureassert UC (Right-click sauc-tutorial-101
	//   project->Sureassert UC->Enable), you'll see a green tick in the margin.
	//   This indicates that the Exemplar was executed successfully and the "expect" 
	//   expression evaluated to true.  Hover over the green tick and you'll see
	//   the value the Exemplar returned (3) and confirmation that the "expect"
	//   expression evaluated to true (=(retval,3)).  This demonstrates that 
	//   if you provide an "expect" expresison that doesn't evaluate to a boolean
	//   the Exemplar will automatically compare it to the value returned by the 
	//   method (retval). 
	//
	// - Your @Exemplar annotated methods should always also have a javadoc which 
	//   documents the method contract.  Think of the @Exemplars as documenting
	//   example usages of the method and enforcing the scenarios they describe. 
	// ==============================================================================
	@Exemplar(args={"1", "2"}, expect="3")
	public int add(int x, int y) {
		
		return x + y; 
	}

	// Sureassert UC Tutorial
	// ==============================================================================
	// - @Exemplar and @UseCase are functionally identical and interchangeable.
	//   Use whichever you prefer.
	// ==============================================================================
	@UseCase(args={"1", "2"}, expect="3")
	public int add2(int x, int y) {
		
		return x + y;
	} 
	
	/**
	 * Append the given strings, separated by the given separator.
	 * @param values Strings to be joined
	 * @param separator A string to separate the joined values
	 * @return String The joined string
	 */
	// ==============================================================================
	// Sureassert UC Tutorial
	//
	// - The Exemplar is commented out, so the code of this method is untested.
	//   Because there is no test coverage, the code is highlighted red in the editor.
	//
	// - Uncomment the @Exemplar, hit Ctrl+S and spot the mistake!  
	//   The Exemplar is correct - we pass in an array of 3 Strings
	//   and expect the method to append them together separated by spaces.  Hover
	//   over the purple cross for details of the error.  Note the Exemplar error
	//   is treated by Eclipse as an error in your project (take a look at the 
	//   Problems View).
	//
	// - Hover over the left margin to see details of test coverage for each line
	//   of code.
	//
	// - Note that for methods with only one line of code, no test coverage is 
	//   recorded or required by default.  This is configurable in the preferences
	//   page (Window->Preferences->Sureassert UC).
	//
	// - Fix the mistake in the code and hit Ctrl+S to remove the error marker.
	// ==============================================================================
	//
	// Un-comment me - @Exemplar(args={"a:'three','blind','mice'", "' '"}, expect="'three blind mice'")
	public String appendString(String[] values, String separator) {
		StringBuilder appendedStr = new StringBuilder();
		for (int i = 1; i < values.length; i++) {
			appendedStr.append(values[i]);
			if (i < values.length - 1)
				appendedStr.append(separator); 
		}  
		return appendedStr.toString();
	} 
	
	/**
	 * Splits the given string, using the given separator to determine the split 
	 * point, into a list of strings.
	 * @param str The string to be split
	 * @param separat The separator within str to be used to split str 
	 * @return List The list of split strings
	 */
	// ==============================================================================
	// Sureassert UC Tutorial
	//
	// - Here we define multiple Exemplars for a method, which requires the use of 
	//   the @Exemplars annotation to aggregate them.  The results for each 
	//   can be seen separately under each green tick.
	//
	// - Any Exemplar can optionally be given a name.  The relevance of this is
	//   highlighted in the next example.
	// ==============================================================================
	@Exemplars(set={
	@Exemplar(name="split1", args={"'a,b,c'", "','"}, expect="l:'a','b','c'"),  
	@Exemplar(name="split2", args={"'x:y:z'", "':'"}, expect="l:'x','y','z'") })
	public List<String> split(String str, String separator) {  
		 
		String[] splitStr = str.split(separator);
		return Arrays.asList(splitStr); 
	}
	
	/**
	 * Builds a Map with the given keys mapped to the given values.
	 * The given key and value lists must be the same size.
	 * @param keys A list of keys
	 * @param values A list of values
	 * @return Map A map of the given keys mapped against the given values.
	 */
	// ==============================================================================
	// Sureassert UC Tutorial
	//
	// - This demonstrates use of the list and map SIN types for building collections
	//   of objects for use within Exemplars.
	//
	// - Also note the references to "split1" and "split2".  These expressions 
	//   return the instance returned by the named Exemplars in the split method 
	//   above.  Referenced Exemplars can be defined anywhere in the workspace
	//   including other projects.  If we used "split1!" as an argument (i.e. append
	//   a "!"),  the referenced Exemplar would be re-executed and the returned 
	//   instance used.  See the @Exemplar javadoc for more details.
	//
	// - Some of the Exemplars expect an Exception to be thrown.
	//
	// - The final Exemplar executes the List.get method to get the objects at
	//   indexes in the split2 list.  Embedded expressions such as this must be  
	//   supplied within square brackets.
	//
	// - Note the assert statement in the code, try changing the int i = 0 to 1 and
	//   you will see an error appear here -- Sureassert UC always runs with
	//   assertions enabled.
	// ==============================================================================
	@Exemplars(set={
    @Exemplar(args={"split1", "split2"}, expect="m:'b'='y','c'='z','a'='x'"),
    @Exemplar(args={"split1", "null"}, expectexception="IllegalArgumentException"),
    @Exemplar(args={"null", "split2"}, expectexception="IllegalArgumentException"),
    @Exemplar(args={"split1", "l:1,2"}, expectexception="IllegalArgumentException"), 
	@Exemplar(args={"l:1,2,3", "split2"}, expect="m:1=[split2.get(0)],2=[split2.get(1)],3=[split2.get(2)]")})
	public <K,V> Map<K, V> buildMap(List<K> keys, List<V> values) {   
		
		if (keys == null) 
			throw new IllegalArgumentException("keys cannot be null");
		if (values == null)
			throw new IllegalArgumentException("values cannot be null");
		if (keys.size() != values.size())
			throw new IllegalArgumentException(String.format(// 
					"keys size (%d) not equal to values size (%d)", keys.size(), values.size()));
		
		Map<K,V> map = new HashMap<K,V>(); 
		for (int i = 0; i < keys.size(); i++) {
			map.put(keys.get(i), values.get(i));
		}
		assert map.size() == keys.size();
		
		return map; 
	}
	
	/**
	 * Gets the highest score from the given score file contents
	 * and registers it with the game service.
	 * @param scoreFile The score file: a properties file in format name=score
	 * @return The high score
	 * @throws IOException If an unexpected I/O problem occurred
	 * @throws HighScoreNotRegisteredException If the score could not be registered with
	 * the remote service
	 */
	// ==============================================================================
	// Sureassert UC Tutorial
	//
	// - Here we pass in a File instance using the f: SIN Type, giving it the 
	//   filename of a test file relative the project directory.  See also the sf:
	//   type which reads a file and returns a String of the file contents. 
	//   
	// - Think of SIN Types are built-in shortcuts for creating objects for use in your 
	//   tests.  You can also define your own SIN Types; take a look at the 
	//   @SINType annotation.
	//
	// - We expect a long value which requires use of the "l" postfix in the expect
	//   expression.
	//
	// - Note the stubs statement. This allows you to "stub" any method in your 
	//   workspace source-path (note - not external libraries).  The left-hand-side
	//   before the "=" is the signature to match.  Each argument is a match 
	//   expression that defaults here to isa(arg,String) - in other words it 
	//   matches invocations of registerHighScore where the first arg is a String.
	//   You could change it to =(arg,'NMD') and it'd do the same thing, but there
	//   you'd only be stubbing invocations of registerHighScore where the first
	//   arg equals 'NMD'.  
	//
	// - The right-hand-side of the "=" of the stub statement is what the stub should
	//   return.  Here we just return the value boolean true.  But you could use
	//   an expression that invoked a method to return a stub value.  The only 
	//   constraint is that, of course, the expression must return an object whose
	//   type matches the return type of the method being stubbed.
	//
	// - Stubbing is a key part of Sureassert UC and there are other options to 
	//   explore - see the phoneshop example, annotation javadocs and website for 
	//   more.
	//
	// - You can also perform behaviour verification from your @Exemplars using
	//   verify as is done here.  Verify statements are just the same as the 
	//   left-hand-side of stubs - i.e. you can define argument matcher expressions
	//   that must be met during execution.  
	//
	// - The verify statement is provided to serve the example, but actually you
	//   would be served better here by changing the "stubs" to a "vstubs" and 
	//   removing the verify.
	//   A vstub is defined the same as a stub; the difference is it *must* be 
	//   executed in order for the Exemplar to pass - in other words its both 
	//   a stub and a verify.
	//
	// ==============================================================================
	@Exemplars(set={
	@Exemplar(args="f:src/test/resources/scorefile1.txt", expect="1403000l", 
			stubs="Tutorial101.registerHighScore(String, long)=true",
			verify="Tutorial101.registerHighScore(String, long)"),
	@Exemplar(args="f:src/test/resources/scorefile1.txt", expect="retval.getMessage().equals('test msg')",
			expectexception="RemoteException",
			stubs="Tutorial101.registerHighScore(String, long)^=new java/rmi/RemoteException('test msg')") })
	public long registerHighScore(File scoreFile) throws IOException, HighScoreNotRegisteredException {
		            
		String highScoreName = null;
		long highScore = 0;
		Properties scores = new Properties();
		Reader fileReader = new FileReader(scoreFile);
		try { 
			scores.load(fileReader);
			for (Entry<Object, Object> scoreEntry : scores.entrySet()) {
				String scoreName = (String)scoreEntry.getKey();
				long score = Long.parseLong((String)scoreEntry.getValue());
				if (score > highScore) {
					highScore = score;
					highScoreName = scoreName;
				} 
			}
			boolean isRegistered = false;
			if (highScoreName != null) {
				isRegistered = registerHighScore(highScoreName, highScore);
			}
			if (!isRegistered) 
				throw new HighScoreNotRegisteredException(); 

			return highScore; 
		} finally {
			fileReader.close(); 
		}
	}
	
	@IgnoreTestCoverage
	private boolean registerHighScore(String name, long highScore) throws UnknownHostException, IOException {

		PrintWriter out = null;
		try {
			// Connect to the remote Billing Service
			Socket socket = new Socket("NonExistentHighScoreService", 123);
			out = new PrintWriter(socket.getOutputStream(), true);
			out.write(Long.toString(highScore));
			return true;
		} finally {
			if (out != null)
				out.close();
		}  
	} 
	
}
