/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.sauc101;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Map.Entry;
import java.util.Properties;

import org.sureassert.uc.annotation.Exemplar;
import org.sureassert.uc.annotation.Exemplars;

/**
 * An example class showing examples of source-level stubbing using 
 * Sureassert UC.
 * 
 * Source stubbing allows you to stub out code in the source code itself
 * rather than declaratively.  This is done using special comments in your code.
 * 
 * Other stubbing options are available; see Tutorial101 and phoneshop for examples.
 */
public class SourceStubbingExample {
 	
	/**
	 * Gets the highest score from the given score file contents
	 * and registers it with the game service.
	 * @param scoreFile The score file: a properties file in format name=score
	 * @return The high score
	 * @throws IOException If an unexpected I/O problem occurred
	 * @throws HighScoreNotRegisteredException If the score could not be registered with
	 * the remote service
	 */
	// ==============================================================================
	// Sureassert UC Tutorial
	//
	// - This method calls an external service via the registerHighScore method.
	//   This is an example of code that cannot be covered by a Exemplar or unit
	//   testing in general.  An integration test would be required, which would
	//   run in an environment where the external service was available to test
	//   against.  
	//
	// - Usually you might use a method stub or a mock.  Here we will use a Sureassert
	//   source stub.  The call to registerHighScore is stubbed using a source stub,
	//   demarked by @Stub inside a code comment, inside square brackets.  
	//   The next code statement or block is not executed when running the Exemplar. 
	// 
	// - Optionally you can also provide code to replace the stub code, which
	//   we have done here ("registered = (Boolean)[$registered];").
	//
	// - You may also use variables inside the stub code, the value of which are
	//   then defined from your Exemplars, for example here we have assigned
	//   the stub variable "registered" the value true.  We could then add another
	//   Exemplar to test the isRegistered=false flow, which is currently identified
	//   as untested (no coverage).  Note the Exemplar in which you define the stub 
	//   variable could be from a different class and method to the stubbed code,
	//   and you can also define stub variables on JUnit tests.
	//
	// - Source stubbing is just one of the ways you can stub code using 
	//   Sureassert UC, and you may well prefer alternate means of stubbing. 
	//   Test double classes and method stubbing are ways of stubbing classes and
	//   methods without modifying your source code.  
	//   See the more comprehensive Phone Shop example project for more on these. 
	//
	// - If you don't like source stubbing and you don't want anyone to use it,
	//   disable it (Window->Preferences->Sureassert UC->Allow Source Stubs)
	// ==============================================================================
	@Exemplar(args="f:src/test/resources/scorefile1.txt", expect="1403000l", 
			stubs="registeredStubVal=true")
	public long registerHighScore(File scoreFile) throws IOException, HighScoreNotRegisteredException {
 
		String highScoreName = null;
		long highScore = 0;
		Properties scores = new Properties();
		Reader fileReader = new FileReader(scoreFile);
		try {
			scores.load(fileReader);
			for (Entry<Object, Object> scoreEntry : scores.entrySet()) {
				String scoreName = (String)scoreEntry.getKey();
				long score = Long.parseLong((String)scoreEntry.getValue());
				if (score > highScore) {
					highScore = score;
					highScoreName = scoreName;
				}
			}
			boolean isRegistered = false;
			if (highScoreName != null) {
				// [@Stub isRegistered = (Boolean)[$registeredStubVal]; ]
				isRegistered = registerHighScore(highScoreName, highScore);
			} 
			if (!isRegistered)
				throw new HighScoreNotRegisteredException(); 
 
			return highScore; 
		} finally {  
			fileReader.close(); 
		}
	}

	
	/**
	 * Gets the highest score from the given score file contents
	 * and registers it with the game service.
	 * @param scoreFileStr The score file as a String; a properties
	 * file in format name=score
	 * @return The high score
	 * @throws IOException 
	 * @throws HighScoreNotRegisteredException 
	 */
	// ==============================================================================
	// Sureassert UC Tutorial
	//
	// - Here we go a few steps further than above. 
	//   We use @StubInsert to insert code without removing the next statement/block. 
	//   The inserted code uses [?registered] to get whether the stub variable 
	//   registered has been defined, if so it sets isRegistered to the value of
	//   that variable, otherwise it executes the actual code in the source.  We need
	//   another @StubInsert below to close the else block.
	//
	// - We can then run 3 Exemplars that demonstrate each of these flows.
	//
	// - Note this is a somewhat artificial example given we would never want to run 
	//   the registerHighScore method in a Exemplar as it relies on an external 
	//   resource.
	//
	// - You can mark a @Stub to be ignored by adding @Ignore to the start of the 
	//   comment.
	//
	// - Sureassert UC will report compilation errors in the modified code should
	//   you attempt to insert stub code that does not compile.
	// ==============================================================================
	@Exemplars(set={
	@Exemplar(args="f:src/test/resources/scorefile1.txt", expect="1403000l", stubs="registeredStub=true"),
	@Exemplar(args="f:src/test/resources/scorefile1.txt", stubs="registeredStub=false", expectexception="HighScoreNotRegisteredException"),
	@Exemplar(args="f:src/test/resources/scorefile1.txt", expectexception="UnknownHostException") })
	public long registerHighScore2(File scoreFile) throws IOException, HighScoreNotRegisteredException {
		 
		String highScoreName = null; 
		long highScore = 0;
		Properties scores = new Properties();
		Reader fileReader = new FileReader(scoreFile);
		try {
			// @Ignore [@Stub ...stub declaration ignored due to @Ignore...]
			scores.load(fileReader);
			for (Entry<Object, Object> scoreEntry : scores.entrySet()) {
				String scoreName = (String)scoreEntry.getKey();
				long score = Long.parseLong((String)scoreEntry.getValue());
				if (score > highScore) { 
					highScore = score;
					highScoreName = scoreName; 
				}
			}
			boolean isRegistered = false;
			if (highScoreName != null) {
				// [@StubInsert if ([?registeredStub]) isRegistered = (Boolean)[$registeredStub]; else {]
				isRegistered = registerHighScore(highScoreName, highScore);
				// [@StubInsert }]
			}
			
			if (!isRegistered)
				throw new HighScoreNotRegisteredException();
 			
			return highScore;
		} finally {
			fileReader.close();
		}
	}
	
	private boolean registerHighScore(String name, long highScore) throws UnknownHostException, IOException {

		PrintWriter out = null;
		try {
			// Connect to the remote Billing Service
			Socket socket = new Socket("_NonExistentHighScoreService_", 123);
			out = new PrintWriter(socket.getOutputStream(), true);
			out.write(Long.toString(highScore));
			return true;
		} finally {
			if (out != null)
				out.close();
		}
	}
}
