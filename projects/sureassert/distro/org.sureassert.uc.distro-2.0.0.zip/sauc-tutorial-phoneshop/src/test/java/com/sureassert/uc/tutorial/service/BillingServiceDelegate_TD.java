/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.service;

import org.sureassert.uc.annotation.TestDouble;

import com.sureassert.uc.tutorial.data.Customer;
import com.sureassert.uc.tutorial.data.Handset;
import com.sureassert.uc.tutorial.data.PhonePlan;

//=================================================================================
// Sureassert UC Tutorial:
//
// This is the TestDouble class for BillingServiceDelegate.  The source of 
// BillingServiceDelegate is replaced by this source, and all mention of 
// BillingServiceDelegate_TD in this source is replaced by BillingServiceDelegate. 
//
// If you comment out @TestDouble, you'll see a problem appear in PhoneShopService.
// That's because a Exemplar in PhoneShopService runs the createContract method
// on that class that calls out to the BillingServiceDelegate, and if that isn't
// "doubled" by this test class, it tries to connect to the non-existent 
// remote Billing Service and falls over with a NullPointerException.
//
// This TestDouble just returns new Contracts using a unique ID sequence.
// TestDoubles are useful when you need an intelligent stub to replace an external
// service that is unavailable in a test context.
//
//=================================================================================
@TestDouble(replaces=BillingServiceDelegate.class) 
public class BillingServiceDelegate_TD {
	 
	private static int nextContractID = 0;
	
	public Contract createNewContract(Customer customer, Handset handset,
			PhonePlan plan, double pricePM) {
		
		return new Contract(nextContractID++, customer, handset, plan, pricePM);
	}
} 
