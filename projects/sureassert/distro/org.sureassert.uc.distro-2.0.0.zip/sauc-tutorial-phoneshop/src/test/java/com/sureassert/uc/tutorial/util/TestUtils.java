/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.util;

import java.util.List;

import org.sureassert.uc.annotation.IgnoreTestCoverage;
import org.sureassert.uc.annotation.SINType;

import com.sureassert.uc.tutorial.data.Handset;

//=================================================================================
// Sureassert UC Tutorial:
//
// This is a class used solely for tests, we're not interested in testing this 
// itself so the @IgnoreTestCoverage annotation is used to prevent coverage 
// reporting.
// This annotation can also be used on methods to prevent coverage reporting
// on a single method.
//
//=================================================================================
@IgnoreTestCoverage
public class TestUtils { 

	public static boolean isAllApproved(List<Handset> handsets) {
		for (Handset handset : handsets) {
			if (!handset.isApproved())
				return false;
		} 
		return true;
	}

	//=================================================================================
	// Sureassert UC Tutorial:
	//
	// Use the @SINType annotation to define a prefix for use in SIN Expressions.
	// A SINType method can accept any number of parameters and can return anything
	// (but not void).  
	//
	// If a Exemplar needed to pass as an argument a named ConfigBean, it could
	// use the expression: args="cb:'beanName'" which would pass 'beanName' as the
	// parameter to this method and return the result.
	//
	// SINTypes can only be defined on static methods or methods in classes with
	// a no-args constructor.
	//=================================================================================
	@SINType(prefix="cb")
	public static Object getConfigBean(String beanName) {
		
		// In your app, return a DI object with the given name, e.g. a Spring bean
		return null;
	}
}
