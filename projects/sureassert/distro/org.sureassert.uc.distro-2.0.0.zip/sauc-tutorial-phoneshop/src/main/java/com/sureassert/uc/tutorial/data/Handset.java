/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.data;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.sureassert.uc.annotation.Exemplar;
import org.sureassert.uc.annotation.Exemplars;

/**
 * Encapsulates mobile phone handset data from the database.
 */
public class Handset implements DataTransferObject {

	private final int pk;

	private String make;

	private String model;

	private double price;
	
	private boolean approved; 
	
	public Handset(int pk) {
		this.pk = pk;
	}

	@Exemplars(set={
	@Exemplar(name="i1", args={ "1", "'Acme'", "'BigBrick'", "80d", "false" }),
	@Exemplar(name="i2", args={ "2", "'Pear'", "'oPhone'", "500d", "true" }) })
	public Handset(int pk, String make, String model, double price, boolean approved) {
		this.pk = pk;
		this.make = make;
		this.model = model; 
		this.price = price; 
		this.approved = approved;
	}   
	
	public int getPk() {
		return pk;
	}
  
	public String getMake() {
		return make;
	} 
	
	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}
 
	public void setModel(String model) {
		this.model = model;
	}
 
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public boolean isApproved() {
		return approved;
	}
	
	// ===============================================================
	// Sureassert UC Tutorial:
	//
	// Generally it is overkill to test single-statement methods,
	// especially getters and setters.  Hence by default, Sureassert
	// UC will not consider or highlight single-statement methods as 
	// requiring test coverage.  This can be changed on the Sureassert 
	// UC Preferences page however.
	//
	// Instanceout: Here, we want a test Handset that has been approved
	// and we're using the instanceout property to make this available
	// to other Exemplars.
	//
	// Something else to try: change the body of the method from 
	// "this.approved = approved;" to "this.approved = !approved;" 
	// and hit Ctrl+S.
	// You will see 4 errors appear in the Problems View (depending
	// on your Problems View filter; you may need to select the 
	// sauc-tutorial-phoneshop project to see errors outside of the
	// selected file.)
	// This is because several methods in the project depend on this
	// method working, your change has broken it, which has caused
	// the dependent Exemplars to fail.
	//
	// Change it back, hit Ctrl+S and all the errors should vanish.
	// 
	// ===============================================================
	@Exemplar(instance="i1!", instanceout="i1Approved", args="true", expect="this.approved")
	public void setApproved(boolean approved) {
		this.approved = approved;  
	} 

	public void persist() throws SQLException {

		GenericDAO.instance
				.update(String
						.format(//
						"update Handset set make='%s',model='%s',price='%s',approved='%s' where pk=%d", //
						make, model, price, approved ? "Y" : "N", pk));
	}

	public void delete() throws SQLException {

		GenericDAO.instance.update(String.format(
				"delete from Handset where pk=%d", pk));
	}    

	public static class HandsetFactory implements DTOFactory<Handset> {

		private static final String SQL_HANDSET_BY_PK = "select * from Handset where pk=%d";
		
		public Handset getHandsetByID(int id) {
			return GenericDAO.instance.queryOne(String.format(SQL_HANDSET_BY_PK, id), this);
		} 
		
		public Handset createDTO(ResultSet resultSet) throws SQLException {

			return new Handset(resultSet.getInt("pk"),
					resultSet.getString("make"), resultSet.getString("model"),
					resultSet.getDouble("price"), resultSet.getString("approved").equals("Y"));
		}
	} 
}
