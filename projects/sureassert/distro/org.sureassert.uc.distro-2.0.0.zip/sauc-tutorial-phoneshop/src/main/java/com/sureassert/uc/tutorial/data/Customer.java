/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.sureassert.uc.annotation.Exemplar;
import org.sureassert.uc.annotation.Exemplars;

public class Customer implements DataTransferObject {

	private final int pk;

	private String name;

	private String address;

	private CreditRating creditRating;

	public enum CreditRating {
		POOR, OKAY, GREAT
	};

	@Exemplars(set={
	@Exemplar(name="good", args={"1", "'John Doe'", "'1 The Street\nABC123'", "CreditRating.GREAT"}),
	@Exemplar(name="okay", args={"3", "'John Doe'", "'1 The Street\nABC789'", "CreditRating.OKAY"}),
	@Exemplar(name="poor", args={"2", "'Jane Doe'", "'2 The Street\nABC456'", "CreditRating.POOR"})})
	public Customer(int pk, String name, String address, CreditRating creditRating) {
		this.pk = pk;
		this.name = name;
		this.address = address;
		this.creditRating = creditRating;
	}
 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}
 
	public void setAddress(String address) {
		this.address = address;
	}

	public CreditRating getCreditRating() {
		return creditRating;
	}

	public void setCreditRating(CreditRating creditRating) {
		this.creditRating = creditRating;
	}

	public int getPk() {
		return pk;
	}
	
	public String toString() {
		return pk + ": " + name + " | " + address + " | " + creditRating;
	}

	public void persist() throws SQLException {

		String sql = String.format(//
				"update Customer set name='%s',address='%s',creditRating='%s' where pk=%d", //
				name, address, creditRating.toString(), pk);
		GenericDAO.instance.update(sql);
	}

	public void delete() throws SQLException {

		String sql = String.format("delete from Customer where pk=%d", pk);
		GenericDAO.instance.update(sql);
	}
	
	public static class CustomerFactory implements DTOFactory<Customer> {
		
		private static final String SQL_CUSTOMER_BY_PK = "select * from Customer where pk=%d";
 		
		public Customer getCustomerByID(int id) {
			return GenericDAO.instance.queryOne(String.format(SQL_CUSTOMER_BY_PK, id), this);
		} 

		// =================================================================================
		// Sureassert UC Tutorial:
		// 
		// This Exemplar demonstrates several features: 1 - you can declare Exemplars on static 
		// inner classes.
		// 
		// More interesting is the args="*".  The * argument instructs Sureassert UC to 
		// create and use a default implementation of the interface or abstract class of the 
		// argument.  For a 3-arg method, you might specify args={"*", "'stringArg'", "*"}
		// to generate default implementations of whatever interfaces are required 
		// for arguments 1 and 3.
		// 
		// The generated default implementation does nothing and returns null or 0 from every
		// abstract method exposed by the interface or abstract class.  Crucially though
		// those generated methods can themselves be stubbed in the usual way with Sureassert
		// UC.  
		//
		// In this example, we create and pass as the only argument, a default ResultSet 
		// implementation (handy given it needs to implement 188 methods.)  
		// 
		// Thirdly, this Exemplar demonstrates the use of the Stub List type, specified
		// using the prefix sl:.  Stub lists are a special type of list used only in stub
		// definitions.  They allow us to specify a value to return (or expression to 
		// execute and return) for each invocation of a stubbed method. 
		// In this example, we stub ResultSet.getString to return a different String for
		// each invocation, as we know the first invocation is to get the Customer's 
		// name, the second his address, and the third his credit rating.  We don't care
		// about the pk so we stick with the default ResultSet.getInt implementation
		// for that, which will return 0.
		//
		// Lastly, note the use of ^= in the second Exemplar's stubs definition, which
		// allows your stubs to throw an exception.  The stub expression in this case must
		// evaluate to an exception type that is thrown from the stubbed method (or a 
		// RuntimeException).
		// Here we're stubbing ResultSet.getString to throw an SQLException and expect
		// our method to return null in response.
		//
		// JDK7 Users Note - Because the ResultSet interface has been changed, you will 
		// experience an Error if running Eclipse under JDK7 whilst compiling this project
		// with JDK6, or vice-versa.  This is because Sureassert default classes are created 
		// using the JDK Eclipse is running under, and this will see a different ResultSet
		// interface.
		// =================================================================================
		@Exemplars(set={
		@Exemplar(args="*", vstubs="ResultSet.getString=[sl:'Joe','1 The Street','POOR']"),
		@Exemplar(a="*", s="ResultSet.getString^=new java/sql/SQLException()", e="null") })   
 		public Customer createDTO(ResultSet resultSet) {
 
			try {
				return new Customer(resultSet.getInt("pk"), 
						resultSet.getString("name"), resultSet.getString("address"), 
						CreditRating.valueOf(resultSet.getString("creditRating")));
			} catch (SQLException e) {
				// ... log error and return null
				return null; 
			} 
		}    
	} 
	 
	@Exemplar(args="m:'key1'=[l:1,2,3],'key2'=[l:4,5,6]", expect="$arg1.get('key2').get(2).equals(7)")
	public static void incrementAll(Map<String, List<Integer>> map) {

		for (List<Integer> intList : map.values()) {
			for (int i = 0; i < intList.size(); i++) {
				intList.set(i, intList.get(i) + 1);
			}
		}
	}

}