/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.service;

import java.util.List;

import com.sureassert.uc.tutorial.data.Customer;
import com.sureassert.uc.tutorial.data.Customer.CustomerFactory;
import com.sureassert.uc.tutorial.data.Handset;
import com.sureassert.uc.tutorial.data.Handset.HandsetFactory;
import com.sureassert.uc.tutorial.data.PhonePlan;
import com.sureassert.uc.tutorial.data.PhonePlan.PhonePlanFactory;
import com.sureassert.uc.tutorial.data.RecordNotFoundException;

public class PhoneShopService implements IPhoneShopService {
 
	public Contract createContract(int agentID, int customerID, int handsetID, 
			int planID, double paidUpFront) throws HandsetNotApprovedException, RecordNotFoundException {

		// Pre-conditions 
 		Customer customer = new CustomerFactory().getCustomerByID(customerID);
		if (customer == null) 
			throw new RecordNotFoundException(customerID, "No Customer found");
		Handset handset = new HandsetFactory().getHandsetByID(handsetID);
		if (handset == null)
			throw new RecordNotFoundException(handsetID, "No Handset found");
		PhonePlan plan = new PhonePlanFactory().getPhonePlanByID(planID);  
		if (plan == null)
			throw new RecordNotFoundException(planID, "No PhonePlan found");
 
		if (!handset.isApproved()) {   
			throw new HandsetNotApprovedException();
		}   
		// ==============

		// Calculate price 
		PricingEngine pricingEngine = new PricingEngine();
		double pricePM = pricingEngine.getPricePerMonth(paidUpFront, handset, plan, customer);

		// Apply boss discount 
		if (agentID == 1)
			pricePM -= (pricePM * BOSS_DISCOUNT);

		// Use BillingServiceDelegate to persist and return the contract
		BillingServiceDelegate billingService = new BillingServiceDelegate();
		Contract contract = billingService.createNewContract(customer, handset, plan, pricePM);
  
		return contract; 
	} 

	/**
	 * Approves the given handsets for use in contracts.
	 * 
	 * @param handsets
	 *            A list of handsets to approve
	 * @return The number of handsets approved (not including those that were
	 *         already approved before invocation of this method)
	 */
	public int approveHandsets(List<Handset> handsets) {
		int numUpdated = 0;
		for (Handset handset : handsets) {
			if (!handset.isApproved()) { 
				numUpdated++;
				handset.setApproved(true); 
			}
		}    
		return numUpdated;    
	}        
   
}
