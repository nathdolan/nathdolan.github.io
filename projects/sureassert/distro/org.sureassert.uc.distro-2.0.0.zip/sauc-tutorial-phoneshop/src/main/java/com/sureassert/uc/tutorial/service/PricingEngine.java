/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.service;

import org.sureassert.uc.annotation.Exemplar;
import org.sureassert.uc.annotation.Exemplars;

import com.sureassert.uc.tutorial.data.Customer;
import com.sureassert.uc.tutorial.data.Customer.CreditRating;
import com.sureassert.uc.tutorial.data.Handset;
import com.sureassert.uc.tutorial.data.PhonePlan;

public class PricingEngine {

	private final double PRICE_PER_MINUTE = 0.02;
	private final double PRICE_PER_TEXT = 0.01;
	private final double DATA_ALLOWANCE_PRICE = 5;
	private final double DEFAULT_LOAN_INTEREST = 0.1;

	/**
	 * Calculates the price a customer must pay per month for a mobile phone
	 * contract.
	 * 
	 * @param paidUpFront
	 *            The amount paid up-front
	 * @param handset
	 *            The handset details
	 * @param plan
	 *            The monthly plan details
	 * @param customer
	 *            The customer details
	 * @return The amount the customer must pay per month
	 */   
	// =================================================================================
	// Sureassert UC Tutorial:
	// 
	// Exemplars can be debugged.  Try adding a breakpoint to this method then 
	// right-clicking in the java editor -> Debug As -> Sureassert UC.
	// Sureassert UC logs Exemplars run and result to the Console and you can use the
	// Debug window to analyse the values being passed in to the method by the Exemplar.
	// 
	// You can run a whole project in the same way, or run every project in the
	// workspace as a standalone build job using the Sureassert UC Workspace Runner 
	// in the Run/Debug Launch menu.  Note the process exit code can be used to 
	// determine the number of errors found.
	//
	// The Exemplars in this example use the short-hand versions of the args and
	// expects parameters which behave in the same way as the more verbose parameters.
	//
	// The fourth Exemplar here demonstrates the new MyClass(args){fieldN=valueN,...}
	// SIN notation.  Using this you can set internal field values of new objects 
	// created for your tests.  It works regardless of whether they're public or private.
	// =================================================================================
	@Exemplars(set={  
	@Exemplar(a={"20d", "Handset/i1!", "PhonePlan/i1!", "Customer/good!"}, e="16.125"),
	@Exemplar(a={"20d", "Handset/i1!", "PhonePlan/i1!", "Customer/poor!"}, e="16.5"),
	@Exemplar(a={"200d", "Handset/i1!", "PhonePlan/i1!", "Customer/okay!"}, e="15.55"), 
	@Exemplar(a={"100d", "new Handset(1) {price=25000,make='DiamondEncrusted'}", "PhonePlan/i1!", "Customer/poor!"}, e="223.5") })
	public double getPricePerMonth(double paidUpFront, Handset handset,
			PhonePlan plan, Customer customer) {         
    
		// Factor price of handset against amount paid up-front 
		double outstanding = handset.getPrice() - paidUpFront;
        
		// Calculate plan price    
		double planPricePM = (plan.getNumInclusiveMins() * PRICE_PER_MINUTE)
				+ (plan.getNumInlcusiveTxts() * PRICE_PER_TEXT);
		if (plan.isIncludesDataAllowance())
			planPricePM += DATA_ALLOWANCE_PRICE;

		// Calculate interest rate of handset loan
		double loanInterestRate = DEFAULT_LOAN_INTEREST;
		if (customer.getCreditRating() == CreditRating.GREAT)
			loanInterestRate *= 0.5;
		if (customer.getCreditRating() == CreditRating.OKAY)
			loanInterestRate *= 0.9;
		if (customer.getCreditRating() == CreditRating.POOR)
			loanInterestRate *= 2;
		double totalLoanInterest = outstanding * loanInterestRate;
   
		// Apply outstanding debt/credit for handset to price per month
		planPricePM = planPricePM
				+ (totalLoanInterest / plan.getContractLengthMonths());

		return planPricePM;
	} 
}    
