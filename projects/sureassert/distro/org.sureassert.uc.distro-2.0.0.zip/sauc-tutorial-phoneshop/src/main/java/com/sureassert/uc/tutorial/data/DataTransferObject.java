/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */package com.sureassert.uc.tutorial.data;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Interface for all data transfer objects. A data transfer object is used to
 * encapsulate data retrieved from the application database.
 */
public interface DataTransferObject {

	/**
	 * Where this is a new record, inserts it in the database. <br/>
	 * Otherwise updates changed fields.
	 */
	public void persist() throws SQLException;

	/**
	 * Deletes this record from the database.
	 */
	public void delete() throws SQLException;

	/**
	 * Factory class used to create instances of a DTO by parsing a ResultSet
	 * retreived from the database.
	 * 
	 * @param <T>
	 *            The type of DTO this factory creates
	 */
	public interface DTOFactory<T extends DataTransferObject> {

		/**
		 * Creates a new DataTransferObject using the given ResultSet, which
		 * must contain data consistent with the type of this DTOFactory.
		 * 
		 * @param resultSet
		 * @return
		 */
		public T createDTO(ResultSet resultSet) throws SQLException;
	}
}
