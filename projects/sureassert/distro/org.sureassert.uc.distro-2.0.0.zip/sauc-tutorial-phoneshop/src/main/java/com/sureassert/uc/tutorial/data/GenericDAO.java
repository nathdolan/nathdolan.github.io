/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.sureassert.uc.annotation.IgnoreTestCoverage;

import com.sureassert.uc.tutorial.data.DataTransferObject.DTOFactory;

@IgnoreTestCoverage
public class GenericDAO {

	private DataSource dataSource;  

	private Connection connection; 

	public static final GenericDAO instance = new GenericDAO();

	/**
	 * Creates a new GenericDAO. Connects to the default DataSource and creates
	 * a Connection.
	 */
	private GenericDAO() {  

		this.dataSource = new AcmeDatabaseDataSource();
		try {
			connection = getConnection(dataSource);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Gets a connection from the given data source.
	 * 
	 * @param dataSource
	 * @return a new Connection
	 * @throws SQLException
	 */
	private Connection getConnection(DataSource dataSource) throws SQLException {

		return dataSource.getConnection();
	}

	public <T extends DataTransferObject> T queryOne(String sql,
			DTOFactory<T> dtoFactory) {
		List<T> list = query(sql, dtoFactory);
		if (list == null || list.isEmpty())
			return null;
		else
			return list.get(0);
	}

	public <T extends DataTransferObject> List<T> query(String sql,
			DTOFactory<T> dtoFactory) {

		// Pre-conditions
		if (!sql.startsWith("select "))
			throw new IllegalArgumentException("invalid update SQL: " + sql);
		if (dtoFactory == null)
			throw new IllegalArgumentException("dtoFactory is null");
		// ==============

		List<T> results = new ArrayList<T>();
		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			// Note 
			ResultSet resultSet = (ResultSet)stmt.executeQuery(sql);
			while (resultSet.next()) {
				results.add(dtoFactory.createDTO(resultSet));
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				stmt.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}
		return results;
	}

	public void update(String sql) throws SQLException {

		// Pre-conditions
		if (!sql.startsWith("insert ") && !sql.startsWith("update ")
				&& !sql.startsWith("delete "))
			throw new IllegalArgumentException("invalid update SQL: " + sql);
		// ==============

		Statement stmt = null;
		try {
			stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			stmt.close();
		}
	}
}
