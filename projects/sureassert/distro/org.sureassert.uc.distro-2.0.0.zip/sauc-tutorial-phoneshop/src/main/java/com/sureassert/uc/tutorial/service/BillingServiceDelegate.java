/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import com.sureassert.uc.tutorial.data.Customer;
import com.sureassert.uc.tutorial.data.Handset;
import com.sureassert.uc.tutorial.data.PhonePlan;

// Note - this class is Test-Doubled by BillingServiceDelegate_TD
public class BillingServiceDelegate {
	
	/**
	 * Connects to the Remote Billing Service to create a new mobile phone
	 * contract.
	 * 
	 * @param customer
	 * @param handset
	 * @param plan
	 * @return The created Contract, containing the ID returned by the Billing
	 *         Service.
	 */
	public Contract createNewContract(Customer customer, Handset handset,
			PhonePlan plan, double pricePM) {

		PrintWriter out = null;
		BufferedReader in = null;
		try {
			// Connect to the remote Billing Service
			Socket socket = new Socket("NonExistentService", 123);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));

			// Get the contract ID from the remote Billing Service
			int contractID = Integer.parseInt(in.readLine());

			// Return a Contract object
			return new Contract(contractID, customer, handset, plan, pricePM);

		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			if (out != null)
				out.close();
			try {
				if (in != null)
					in.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}  
		} 
	}
}
