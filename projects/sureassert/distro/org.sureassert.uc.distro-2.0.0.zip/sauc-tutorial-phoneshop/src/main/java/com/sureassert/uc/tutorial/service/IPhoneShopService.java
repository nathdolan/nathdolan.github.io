/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.service;

import java.util.List;

import org.sureassert.uc.annotation.Exemplar;
import org.sureassert.uc.annotation.Exemplars;

import com.sureassert.uc.tutorial.data.Handset;
import com.sureassert.uc.tutorial.data.RecordNotFoundException;

public interface IPhoneShopService {

	final double BOSS_DISCOUNT = 0.1; // 10% discount
	
	/**
	 * Creates a new mobile phone contract.
	 * 
	 * @param agentID The ID of the agent who made the sale
	 * @param customer The customer details
	 * @param handset The handset details
	 * @param plan The monthly plan details
	 * @param paidUpFront  The amount the customer wishes to pay up-front
	 * @return The contract 
	 * @throws RecordNotFoundException If no record could be found matching the given 
	 * 			IDs.
	 */
	// =================================================================================
	// Sureassert UC Tutorial:
	// 
	// Defining the javadoc and Exemplars on your interfaces is a great way of 
	// abstracting the specification and enforcement from the implementation 
	// in your concrete classes.
	//
	// All implementing classes inherit the Exemplars defined on their interfaces or
	// super-classes.  If you hover over the ticks you'll see that the message is
	// followed by the name of the class on which the Exemplar was executed, in brackets.
	// Were there to be several concrete classes that implement this interface, 
	// you'd see messages for each implementing class.
	// 
	// If you include a description, the Exemplar is referred to by this.
	// 
	// =================================================================================
	@Exemplars(set={
			
	@Exemplar(description="Story16a", args={"1", "2", "1", "1", "200d"}, 
			expectexception="RecordNotFoundException", 
			expect={"=(retval.id, 2)"}, 
			stubs={"CustomerFactory.getCustomerByID=null","HandsetFactory.getHandsetByID=Handset/i1","PhonePlanFactory.getPhonePlanByID=PhonePlan/i1"}),
			
	@Exemplar(description="Story16b", args={"1", "1", "3", "1", "200d"}, 
			expectexception="RecordNotFoundException",  
			expect={"=(retval.id, 3)"}, 
			stubs={"CustomerFactory.getCustomerByID=Customer/good","HandsetFactory.getHandsetByID=null","PhonePlanFactory.getPhonePlanByID=PhonePlan/i1"}),

	@Exemplar(description="Story16c", args={"1", "1", "1", "4", "200d"}, 
			expectexception="RecordNotFoundException",  
			expect={"=(retval.id, 4)"}, 
			stubs={"CustomerFactory.getCustomerByID=Customer/good","HandsetFactory.getHandsetByID=Handset/i1","PhonePlanFactory.getPhonePlanByID=null"}),

	@Exemplar(description="Story16d", args={"1", "1", "1", "1", "200d"}, 
			expectexception="HandsetNotApprovedException",  
			stubs={"CustomerFactory.getCustomerByID=Customer/good","HandsetFactory.getHandsetByID=Handset/i1!","PhonePlanFactory.getPhonePlanByID=PhonePlan/i1"}),
		
	@Exemplar(description="Story16e", args={"1", "1", "1", "1", "200d"}, 
			expect="=(retval.pricePM, 14.175d)", 
			stubs={"CustomerFactory.getCustomerByID=Customer/good","HandsetFactory.getHandsetByID=Handset/i1Approved!","PhonePlanFactory.getPhonePlanByID=PhonePlan/i1"})
	})  
	public Contract createContract(int agentID, int customerID, int handsetID,
			int planID, double paidUpFront) throws HandsetNotApprovedException, RecordNotFoundException;
	
	/**
	 * Approves all given handsets. 
	 * @param handsets
	 * @return The number of handsets approved
	 */
	// =================================================================================
	// Sureassert UC Tutorial:
	// 
	// This Exemplar includes 2 expect expressions, both of which do the same things
	// in different ways for the purposes of the tutorial.
	// 
	// The first expect expression is a call to the isAllApproved method in the 
	// com.sureassert.uc.tutorial.util.TestUtils class.  We could have given the full
	// class name (note - you must replace the dots with / 
	// i.e. com/sureassert/uc/tutorial/util/TestUtils.
	// However for any class with source in any Sureassert UC project, this is
	// unnecessary and providing just the simple class name will suffice. 
	// The full class name is required for library classes, or where there is more
	// than one class in your workspace with a given simple name.
	//
	// Note you can Ctrl+click any class name in Eclipse to navigate to that class;
	// this is one of the reasons why prefixing your instance names with their class 
	// name is wise.
	// 
	// $arg1 is a special instance name used to get the object passed into the method
	// by the Exemplar.  Use $arg1, $arg2, $argN etc to get the first, second and Nth
	// method argument.
	// 
	// The second expect expression is totally superfluous but serves to illustrate that
	// chained expressions can be used. It first gets the value of the first method 
	// argument ($arg1), an ArrayList, then invokes get(0) on the list to get the first 
	// element, then gets the value of the approved field (which evaluates to true) 
	// thereby satisfying the expect expression.
	// 
	// =================================================================================
	@Exemplar(args="l:Handset/i1!, Handset/i1Approved",
			expect={"TestUtils.isAllApproved($arg1)", "$arg1.get(0).approved"})
	public int approveHandsets(List<Handset> handsets);   
}   
