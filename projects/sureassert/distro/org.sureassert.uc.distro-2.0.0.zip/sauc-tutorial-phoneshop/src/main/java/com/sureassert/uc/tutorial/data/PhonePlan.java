/*
 * Copyright 2011 Nathan Dolan. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, this 
 *    list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation and/or 
 *    other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 * 
 */
package com.sureassert.uc.tutorial.data;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.sureassert.uc.annotation.Exemplar;

public class PhonePlan implements DataTransferObject {

	private final int pk;

	private String networkName;

	private int contractLengthMonths;
 
	private int numInclusiveMins;

	private int numInlcusiveTxts;

	private boolean includesDataAllowance;
 
	@Exemplar(name="i1", args={"1", "'BigNetwork'", "24", "300", "500", "true"})
	public PhonePlan(int pk, String networkName,
			int contractLengthMonths, int numInclusiveMins,
			int numInlcusiveTxts, boolean includesDataAllowance) {
		this.pk = pk;
		this.networkName = networkName;       
		this.contractLengthMonths = contractLengthMonths;
		this.numInclusiveMins = numInclusiveMins;
		this.numInlcusiveTxts = numInlcusiveTxts;
		this.includesDataAllowance = includesDataAllowance;
	}   

	public int getPk() { 
		return pk;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public int getContractLengthMonths() {
		return contractLengthMonths;
	}

	public void setContractLengthMonths(int contractLengthMonths) {
		this.contractLengthMonths = contractLengthMonths;
	}

	public int getNumInclusiveMins() {
		return numInclusiveMins;
	}

	public void setNumInclusiveMins(int numInclusiveMins) {
		this.numInclusiveMins = numInclusiveMins;
	}

	public int getNumInlcusiveTxts() {
		return numInlcusiveTxts;
	}

	public void setNumInlcusiveTxts(int numInlcusiveTxts) {
		this.numInlcusiveTxts = numInlcusiveTxts;
	}

	public boolean isIncludesDataAllowance() {
		return includesDataAllowance;
	}

	public void setIncludesDataAllowance(boolean includesDataAllowance) {
		this.includesDataAllowance = includesDataAllowance;
	}

	public void persist() throws SQLException {

		GenericDAO.instance
				.update(String
						.format(//
						"update PhonePlan set networkName='%s',contractLengthMonths=%d,"
								+ "numInclusiveMins=%d,numInlcusiveTxts=%d,includesDataAllowance='%s'"
								+ " where pk=%d", //
						networkName, contractLengthMonths, numInclusiveMins,
								numInlcusiveTxts, includesDataAllowance ? "Y"
										: "N", pk));
	}

	public void delete() throws SQLException {

		GenericDAO.instance.update(String.format(
				"delete from PhonePlan where pk=%d", pk));
	}

	public static class PhonePlanFactory implements DTOFactory<PhonePlan> {

		private static final String SQL_PHONE_BY_PK = "select * from PhonePlan where pk=%d";
		
		public PhonePlan getPhonePlanByID(int id) {
			return GenericDAO.instance.queryOne(String.format(SQL_PHONE_BY_PK, id), this);
		}
		
		public PhonePlan createDTO(ResultSet resultSet)
				throws SQLException {

			return new PhonePlan(resultSet.getInt("pk"),
					resultSet.getString("networkName"),
					resultSet.getInt("contractLengthMonths"),
					resultSet.getInt("contractLengthMonths"),
					resultSet.getInt("contractLengthMonths"), 
					resultSet.getString("includesDataAllowance").equals("Y"));
		}
	}
}
