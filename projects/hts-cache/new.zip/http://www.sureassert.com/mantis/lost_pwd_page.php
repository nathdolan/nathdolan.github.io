<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<link rel="stylesheet" type="text/css" href="http://www.sureassert.com/mantis/css/default.css" />
	<script type="text/javascript"><!--
		if(document.layers) {document.write("<style>td{padding:0px;}<\/style>")}
	// --></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Cache-Control" content="no-cache" />
	<meta http-equiv="Pragma-directive" content="no-cache" />
	<meta http-equiv="Cache-Directive" content="no-cache" />
	<meta http-equiv="Expires" content="Sat, 04 Mar 2017 11:47:10 GMT" />
	<meta name="robots" content="noindex,follow" />
	<link rel="shortcut icon" href="/mantis/images/favicon.ico" type="image/x-icon" />
	<link rel="search" type="application/opensearchdescription+xml" title="MantisBT: Text Search" href="http://www.sureassert.com/mantis/browser_search_plugin.php?type=text" />	<link rel="search" type="application/opensearchdescription+xml" title="MantisBT: Issue Id" href="http://www.sureassert.com/mantis/browser_search_plugin.php?type=id" />	<title>MantisBT</title>
<script type="text/javascript" src="/mantis/javascript/min/common.js"></script>
<script type="text/javascript">var loading_lang = "Loading...";</script><script type="text/javascript" src="/mantis/javascript/min/ajax.js"></script>
</head>
<body>
<div align="left"><a href="my_view_page.php"><img border="0" alt="Mantis Bug Tracker" src="/mantis/images/mantis_logo.gif" /></a></div><br /><br />
<div align="center">
<form name="lost_password_form" method="post" action="lost_pwd.php">
<input type="hidden" name="lost_pwd_token" value="20170304e7228000c2bcb6932b31bc2d4a1e88fe44e526cc"/><table class="width50" cellspacing="1">
<tr>
	<td class="form-title" colspan="2">
		Password Reset	</td>
</tr>
<tr class="row-1">
	<td class="category" width="25%">
		Username	</td>
	<td width="75%">
		<input type="text" name="username" size="32" maxlength="32" />
	</td>
</tr>
<tr class="row-2">
	<td class="category" width="25%">
		E-mail	</td>
	<td width="75%">
		<input type="text" name="email" size="32" maxlength="64" value="" />	</td>
</tr>
<tr>
	<td colspan="2">
		<br />
		To reinstate your lost password, please supply the name and e-mail address for the account.<br /><br />If the data corresponds to a valid account, you will be sent a special URL via e-mail that contains a validation code for your account. Please follow this link to change your password.		<br /><br />
	</td>
</tr>
<tr>
	<td class="center" colspan="2">
		<input type="submit" class="button" value="Submit" />
	</td>
</tr>

</table>
</form>
</div>

<br /><div align="center"><span class="bracket-link">[&#160;<a href="login_page.php">Login</a>&#160;]</span> &#160;<span class="bracket-link">[&#160;<a href="signup_page.php">Signup for a new account</a>&#160;]</span> </div><!-- Autofocus JS -->
<script type="text/javascript" language="JavaScript">
<!--
	window.document.lost_password_form.username.focus();
// -->
</script>
	<br />
	<hr size="1" />
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr valign="top"><td>	<address>Copyright &copy; 2000 - 2011 MantisBT Group</address>
</td><td>
	<div align="right"><a href="http://www.mantisbt.org" title="Free Web Based Bug Tracker"><img src="/mantis/images/mantis_logo_button.gif" width="88" height="35" alt="Powered by Mantis Bugtracker" border="0" /></a></div>
</td></tr></table>
</body>
</html>
