<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<link rel="stylesheet" type="text/css" href="http://www.sureassert.com/mantis/css/default.css" />
	<script type="text/javascript"><!--
		if(document.layers) {document.write("<style>td{padding:0px;}<\/style>")}
	// --></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Cache-Control" content="no-cache" />
	<meta http-equiv="Pragma-directive" content="no-cache" />
	<meta http-equiv="Cache-Directive" content="no-cache" />
	<meta http-equiv="Expires" content="Sat, 04 Mar 2017 11:47:09 GMT" />
	<meta name="robots" content="noindex,follow" />
	<link rel="shortcut icon" href="/mantis/images/favicon.ico" type="image/x-icon" />
	<link rel="search" type="application/opensearchdescription+xml" title="MantisBT: Text Search" href="http://www.sureassert.com/mantis/browser_search_plugin.php?type=text" />	<link rel="search" type="application/opensearchdescription+xml" title="MantisBT: Issue Id" href="http://www.sureassert.com/mantis/browser_search_plugin.php?type=id" />	<title>MantisBT</title>
<script type="text/javascript" src="/mantis/javascript/min/common.js"></script>
<script type="text/javascript">var loading_lang = "Loading...";</script><script type="text/javascript" src="/mantis/javascript/min/ajax.js"></script>
</head>
<body>
<div align="center"><a href="my_view_page.php"><img border="0" alt="Mantis Bug Tracker" src="/mantis/images/mantis_logo.gif" /></a></div><br /><div align="center"></div>
<!-- Login Form BEGIN -->
<br />
<div align="center">
<form name="login_form" method="post" action="login.php">
<table class="width50" cellspacing="1">
<tr>
	<td class="form-title">
						<input type="hidden" name="return" value="/mantis/my_view_page.php" />
				Login	</td>
	<td class="right">
		</td>
</tr>
<tr class="row-1">
	<td class="category">
		Username	</td>
	<td>
		<input type="text" name="username" size="28" maxlength="32" value="" />
	</td>
</tr>
<tr class="row-2">
	<td class="category">
		Password	</td>
	<td>
		<input type="password" name="password" size="16" maxlength="32" />
	</td>
</tr>
<tr class="row-1">
	<td class="category">
		Remember my login in this browser	</td>
	<td>
	<input type="checkbox" name="perm_login" />
	</td>
</tr>
<tr class="row-2">
	<td class="category">
		Secure Session	</td>
	<td>
	<input type="checkbox" name="secure_session" checked="checked" />
	<span class="small">Only allow your session to be used from this IP address.</span>	</td>
</tr>
<tr>
	<td class="center" colspan="2">
		<input type="submit" class="button" value="Login" />
	</td>
</tr>
</table>
</form>
</div>

<br /><div align="center"><span class="bracket-link">[&#160;<a href="signup_page.php">Signup for a new account</a>&#160;]</span> &#160;<span class="bracket-link">[&#160;<a href="lost_pwd_page.php">Lost your password?</a>&#160;]</span> </div>
<!-- Autofocus JS -->
<script type="text/javascript" language="JavaScript">
<!--
	window.document.login_form.username.focus();
// -->
</script>

	<br />
	<hr size="1" />
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr valign="top"><td>	<address>Copyright &copy; 2000 - 2011 MantisBT Group</address>
</td><td>
	<div align="right"><a href="http://www.mantisbt.org" title="Free Web Based Bug Tracker"><img src="/mantis/images/mantis_logo_button.gif" width="88" height="35" alt="Powered by Mantis Bugtracker" border="0" /></a></div>
</td></tr></table>
</body>
</html>
